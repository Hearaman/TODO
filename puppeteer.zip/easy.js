const puppeteer = require("puppeteer");
const chalk = require("chalk");
const fs = require('fs').promises;

// MY OCD of colorful console.logs for debugging... IT HELPS
const error = chalk.bold.red;
const success = chalk.keyword("green");

var [compitetor,keyword]=process.argv.slice(2);

console.log(compitetor);


(async () => {
    try {
        // open the headless browser
        var browser = await puppeteer.launch({ headless: false });

        // open a new page
        var page = await browser.newPage();

        /* =========== for best buy====
        const cookiesString = await fs.readFile('./cookies.json');
        const cookies = JSON.parse(cookiesString);
        await page.setCookie(...cookies);
        */

        // enter url in page
        //await page.goto(`https://www.bestbuy.com/site/searchpage.jsp?st=jbl+headset&_dyncharset=UTF-8&_dynSessConf=&id=pcat17071&type=page&sc=Global&cp=1&nrp=&sp=&qp=&list=n&af=true&iht=y&usc=All+Categories&ks=960&keys=keys`, { waitUntil: 'load', timeout: 10000000 });

        await page.goto(`https://www.kohls.com/search.jsp?search=jbl+headphones`);

        await page.waitForSelector("ul.products li.products_grid");

        var products = await page.evaluate(() => {
            var productsGrid=document.querySelectorAll(`ul.products li.products_grid`);

            var productsData = [];
            for (var i = 0; i < productsGrid.length; i++) {

                var isPriceReduced=(productsGrid[i].querySelector(".prod_priceBlock .prod_price_label").innerText.toLowerCase()==='sale')?true:false;

                productsData[i] = {
                    title: productsGrid[i].querySelector("img.pmp-hero-img").getAttribute('title'),
                    image: productsGrid[i].querySelector("img.pmp-hero-img").getAttribute('data-herosrc'),
                    price: productsGrid[i].querySelector(".prod_priceBlock .prod_price_amount").innerText.trim(),
                    isPriceReduced: isPriceReduced,
                    original_price: (isPriceReduced)?productsGrid[i].querySelector(".prod_priceBlock .prod_price_original").innerText.trim():productsGrid[i].querySelector(".prod_priceBlock .prod_price_amount").innerText.trim()

                };
            }
            return productsData;
        });

        //const cookies = await page.cookies();
        //await fs.writeFile('./cookies.json', JSON.stringify(cookies, null, 2));

        // Google Say Cheese!!
        await page.screenshot({ path: "example.png" });

        await browser.close();

        fs.writeFile("kohls.json", JSON.stringify(products), function (err) {
            if (err) throw err;
            console.log("Saved!");
        });

        console.log(success("Browser Closed"));
    } catch (err) {
        // Catch and display errors
        console.log(error(err));
        await browser.close();
        console.log(error("Browser Closed"));
    }
})();