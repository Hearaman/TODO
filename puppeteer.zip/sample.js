var address = 'https://www.kohls.com/search.jsp?submit-search=web-ta-keyword&search=jbl+headphones&S=1&PPP=48&kls_sbp=87673565855293205710645808019797457655';

//address="https://www.dollargeneral.com/products/search-results.html?q=Fructis+Sleek+%26+Shine+Anti+Frizz+Serum";

//address="https://www.bestbuy.ca/en-ca/search?search=JBL+headset";

address="https://www.macys.com/shop/featured/jbl";
address="https://www.walmart.com/search/?query=jbl";
address="https://www.bestbuy.com/site/searchpage.jsp?st=jbl&_dyncharset=UTF-8&_dynSessConf=&id=pcat17071&type=page&sc=Global&cp=1&nrp=&sp=&qp=&list=n&af=true&iht=y&usc=All+Categories&ks=960&keys=keys";

var page = require('webpage').create();

page.settings.userAgent = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.71 Safari/537.36';
page.settings.HTTP_USER_AGENT = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.71 Safari/537.36';
page.viewportSize = { width: 1440, height: 900 };

page.onConsoleMessage = function(msg) {
    //console.log(msg);
};

page.open(address, function(status) {
    if (status !== "success") {
        console.log("Unable to access network");
    }
    else {
        console.log("Accessing");
        page.render("page.png");


        /*
        var exitCode = page.evaluate(function() {
            var li = document.body.querySelectorAll('.products .products_grid');
            for (i = 0; i < li.length; ++i) {
                console.log(li[i].innerText);

                if(i==5){
                    break;
                }
            }
        });*/
    }
    phantom.exit();
});